import {Sequelize} from 'sequelize';

export const sequelize = new Sequelize ('biblioteca','root','root',{
    host:'localhost',
    dialect:'mysql'
});

try{
    await sequelize.authenticate();
    console.log('Conectano ao banco MYSQL');
}catch(error){
    console.error('Erro ao conectar ao Banco', error);
}