import express  from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import livrosRoutes from './routes/livroRoutes.js';
import {sequelize} from './database/connection.js';
const app = express();
app.use(cors());
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: true }))
app.use('/api', livrosRoutes);
const PORT = 3000;
(async () => {
    try{
        await sequelize.sync();
        app.listen(PORT, () =>{
            console.log('servidor rodando a porta 3000');
        });
    }catch(error){
        console.error("erro ao sincronizar com o banco", error);
    }
})();
