import { asyncWrapProviders } from 'async_hooks';
import {Livro} from '../database/models/Livro.js';

//Criar um novo Livro
export const criarLivro = async(req, res) =>{
    try{
        const {nome_livro, nome_autor} = req.body
        const novoLivro = await Livro.create({nome_livro, nome_autor});
        res.status(201).json(novoLivro);
    }catch(error){
        res.status(500).json({erro: error.message});
    }
};

//Listar livros
export const listarlivros = async(req, res) => {
    try{
        const livros = await Livro.findAll();
        res.status(200).json(livros);
    }catch(error){
        res.status(500).json({erro: error.menssage});
    }
};
//Obter livro por ID
export const buscarLivroPorId = async(req, res) => {
    try{
        const livro = await Livro.findByPk(req.params.id);
        if(!livro) return res.status(404).json({mensagem: "Livro não enontrado"});
        res.status(200).json(livro);
    }catch(error){
        res.status(500).json({erro: error.menssage});
    }
};
//Atualizar livro
export const atualizarLivro = async(req, res) => {
    try{
        const livro = await Livro.findByPk(req.params.id);
        if(!livro) return res.status(404).json({mensagem:"Livro não encontrado"});
        await livro.update(req.body);
        res.status(201).json(livro)
    }catch(error){
        res.status(500).json({erro: error.menssage});
    }
};
//Deletar livros
export const deletarLivro = async (req, res) => {
    try{
        const livro = await Livro.findByPk(req.params.id);
        if(!livro) return res.status(404).json({mensagem: 'livro não encontrado'});
        await livro.destroy();
        res.status(201).json({mensagem: 'Livro deletado com sucesso'});
    }catch(error){
        res.status(500).json({erro: error.menssage});
    }

};