import { Router } from 'express';
import {
    criarLivro,
    listarlivros,
    buscarLivroPorId,
    atualizarLivro,
    deletarLivro
} from '../controllers/livroController.js';
const router = Router();
router.post('/livros', criarLivro);
router.get('/livros', listarlivros);
router.get('/livros/:id', buscarLivroPorId);
router.put('/livros/:id', atualizarLivro);
router.delete('/livros/:id', deletarLivro);
export  default router;